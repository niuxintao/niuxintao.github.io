import subprocess
import time
import numpy as np

# 可执行文件列表
executables = ['atomic', 'mutex', 'spin']
# 参数列表
args = [1, 2, 4, 8, 16]
# 存储结果的字典
results = {exe: {arg: [] for arg in args} for exe in executables}

# 运行可执行文件并记录时间
for exe in executables:
    for arg in args:
        times = []
        for _ in range(5):  # 对每个参数运行5次
            start = time.time()
            subprocess.run([f"./{exe}", str(arg)])
            end = time.time()
            times.append(end - start)
        results[exe][arg] = times

# 将数据写入文件
with open('execution_times.txt', 'w') as file:
    for exe in executables:
        for arg in args:
            for time_val in results[exe][arg]:
                file.write(f"{exe} {arg} {time_val}\n")