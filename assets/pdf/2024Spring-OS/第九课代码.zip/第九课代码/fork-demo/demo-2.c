#include <unistd.h>
#include <stdio.h>

int main() {
    for (int i = 0; i < 2; i++) {
        fork();
 //       printf("Hello\n");
	printf("Hello\t");
    }
}
