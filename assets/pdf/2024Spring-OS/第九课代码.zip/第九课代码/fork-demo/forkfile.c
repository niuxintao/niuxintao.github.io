#include <fcntl.h>
#include <stdio.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>

char str[11] = {0};

int main(int argc, char * argv[]){
    int fd = open("test.txt", O_RDWR);
    read(fd, str, 1);
    if (fork() == 0) {
        ssize_t cnt = read(fd, str, 9);
        printf("Child process: %s\n", (char *)str);
    } else {
        //sleep(1);
        size_t cnt = read(fd, str, 9);
        printf("Parent process: %s\n", (char *)str);
    }
    close(fd);
    return 0;
}