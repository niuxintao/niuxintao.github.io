**Stop-the-world 实现互斥**：对于操作系统上的应用程序，关闭中断是不能容忍的：这会使微小的 bug 或是恶意的程序破坏计算机的运行。操作系统正是因为统治了中断，才实现了对应用程序的管理。在操作系统内核的实现中，关闭中断是一个常见的操作。



make cli

./cli

为什么错了

gdb  cli

start

layout asm

si

段错误 





Make 

Make debug

layout asm

si

p/t $cs

p  $eflags 

c

exit

y

kill
