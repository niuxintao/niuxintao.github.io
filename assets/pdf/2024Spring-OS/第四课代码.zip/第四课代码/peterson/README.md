**Peterson 算法**：我们不仅提供了模型、模型的变体，还有 C 语言的实现。Model checker 给了我们探索 Peterson 算法变体的能力：我们可以改变语句执行的顺序等，实现 Peterson 算法的变体，并且由 model checker 给出一个快速的反馈，在反馈的基础上，我们可能更快、更好地理解 Peterson 算法的原理。
