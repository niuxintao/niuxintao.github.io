def make_adder(n):
	""" Returns a function that takes one argument k and returns k + n.
	>>> add_three = make_adder(3)
	>>> add_three(4)
	7
	"""
	def adder(k):
		return k + n
	return adder

