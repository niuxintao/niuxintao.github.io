public class TypeConversion {
	 public static void main(String[] args){
		 byte b = 75;
		 char c = 'c';
		 int i = 794215;
		 long l = 9876543210L;
		 long result = b * c - i + l;

		 System.out.println(result);


		 int x = 100000;

		 result = x * x * x;

		 System.out.println(result);

		 result = x * x * (long)x;

		 System.out.println(result);

//		 result = Math.multiplyExact(x,  x * x);

		 int n = 123456789;
		 float f = n; // f is 1.23456792E8

		 System.out.println(f);

		 int MyInt=1234;
		 String MyString=""+MyInt;
		 int a = Integer.parseInt(MyString);

		 System.out.println(MyString);

	 }
}
