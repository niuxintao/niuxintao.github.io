import java.util.LinkedList;
import java.util.List;

public class ListDemo {
    public static void main(String[] args) {
//        String[] s = new String[3];
//        s[0] = "a";
//        s[1] = "b";
//        s[2] = 1;

        List L = new LinkedList();
        L.add("a");
        L.add("b");
        L.add(1);
        System.out.println(L);
    }
}