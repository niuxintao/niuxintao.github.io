public class InitError {
   static int vacationDays;
    public static int hailstone(int n){
        while (n != 1) {
            if (n % 2 == 0) {
                n = n / 2;
            } else {
                n = 3 * n + 1;
            }
        }
        return n;
    }

    public static void main(String[] args) {
//        int vacationDays;
//
//        if (hailstone(50) == 1){
//            vacationDays = 1;
//        }else{
////            vacationDays = 2;
//        }

        System.out.println(vacationDays); // ERROR--variable not initialized
    }
}
