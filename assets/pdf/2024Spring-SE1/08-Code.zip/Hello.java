class Hello{
    public static void main(String[] args){
        System.out.println("Hello, world!");
//        int a  = "hg";
        Integer a  = 1;
        int b = 1;
        a.intValue();
        System.out.println(a);

    }
}