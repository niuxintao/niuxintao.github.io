public class LoopDemo {

    public static void main(String[] args) {
        int sum = 0;
        int[] sequence = {1, 2, 3, 4};
        for (int j : sequence) {
            int temp = 1;
//            if(j == 2)
//                break;
            for (int i = 1; i <= j; i++){
                temp *= i;
                break;
            }
            sum +=temp;
            System.out.println(sum);
        }
    }
}
