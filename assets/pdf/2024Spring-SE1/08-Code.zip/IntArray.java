public class IntArray {
    public static void main(String[] args) {
        int[] m1;
        m1 = new int[10];
        System.out.println(m1.length);


        int[][] a;
        a = new int[][] {{11,22,33,44}, {66,77,88}};
        for(int[] b : a) {
            for(int c : b) {
                System.out.print(c + " ");
            }
            System.out.println();
        }


        char[][] c = new char[2][];
        c[0] = new char[]{'1','2','3'};
        c[1] = new char[]{'4','5'};
        for(char[] b : c) {
            for(char m : b){
                System.out.print(m + " ");
            }
            System.out.println();
        }

    }
}
