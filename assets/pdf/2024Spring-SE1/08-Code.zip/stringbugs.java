public class stringbugs {
    public static void main(String[] args){
        String a = "abc";
        String b = "abc";
        a.length();
        String str1 = new String("abc");
        String str2 = new String("abc");
        System.out.println( a == b);
        System.out.println( a == str1);
    }
}
