# Print and None
-2

print(-2)

'Go Bears'

print('Go Bears')

None

print(None)

x = -2

x

x = print(-2)

x

print(x)

print(1, 2, 3)

print(None, None)

print(print(1), print(2))



# Nested Expressions with Print

print(1)

x = print(1)

print(x)

print(print(1))

y = print(2)

print(x, y)

print(print(1), print(2))



# Print vs Return

# Using return
def f():
    return 'stuff'

x = f()

x

'some ' + x

# Using print
def f():
    print('stuff')

x = f()

x

print(x)

'some ' + x

