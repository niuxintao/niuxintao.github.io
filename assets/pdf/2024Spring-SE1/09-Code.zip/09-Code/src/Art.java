class Art {
    Art() {
        System.out.println("Art Constructor");
    }
}