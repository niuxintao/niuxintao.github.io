package abstractandinterface;

public interface Face2 {
    default void setColor(String c){
        System.out.println("颜色是 ： "+ c);
    }
    abstract void volume();
}