package abstractandinterface;

public interface IShape {
    public static final double PI = 3.14;
    double getArea();
    public abstract double getLength();
    public static void showPI(){
        System.out.println(PI);
    }
    public default void getInfo(){
        System.out.println("这是一个图形");
    }
}