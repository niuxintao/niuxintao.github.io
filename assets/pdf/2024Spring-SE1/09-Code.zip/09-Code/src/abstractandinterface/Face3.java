package abstractandinterface;

public interface Face3 extends Face1, Face2 {
    static final double PI = 3.1415;
    public default void setColor(String c){
        System.out.println("颜色是 ： "+ c + "3");
//        System.out.println("PI： "+ PI +  "  parent PI: "+ super.PI);
    }
}