package abstractandinterface;

public class SimpleSetColor {
    protected double x;
    public void setColor(String c){
        System.out.println("颜色是Simple ： "+ c);
    }
    protected String set(){return "0";}
}