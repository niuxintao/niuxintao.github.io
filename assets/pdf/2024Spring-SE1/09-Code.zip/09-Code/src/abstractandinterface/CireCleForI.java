package abstractandinterface;

public class CireCleForI implements IShape{
    double radius;
    public CireCleForI(double r){
        this.radius = r;
    }
    public double getArea() {
        return PI*radius*radius;
    }
    public double getLength() {
        return 2*PI*radius;
    }
    public static void main(String[] args){
        IShape cir = new CireCleForI(2.2);
        System.out.println("面积 ： "+ cir.getArea());
        System.out.println("周长 ： "+ cir.getLength());
        cir.getInfo();
        IShape.showPI();
    }
}

