package abstractandinterface;

public class Circle extends Shape {
    private final static double PI = 3.14;
    private double radius;

    public Circle(String xm, double r) {
        super(xm);
        this.radius = r;
    }

    public double getArea() {
        return PI*radius*radius;
    }

    public double getLength() {
        return 2*PI*radius;
    }

    public static void main(String[] args){
        Circle circle = new Circle("abstractandinterface.Circle Center", 5);
        System.out.println(circle.getArea());
    }
}