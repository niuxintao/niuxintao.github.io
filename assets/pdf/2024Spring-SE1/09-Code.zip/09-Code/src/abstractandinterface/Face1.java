package abstractandinterface;

public interface Face1 {
    static final double PI = 3.14;
    abstract double area();
}