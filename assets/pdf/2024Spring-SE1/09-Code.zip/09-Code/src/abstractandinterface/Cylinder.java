package abstractandinterface;

public class Cylinder extends SimpleSetColor implements Face2 {

    private double radius;
    private int height;
    protected String color;
    private boolean x;

    public Cylinder( double r,int  h){
        this.radius = r;
        this.height = h;
    }
    public double area() {
        return Face1.PI*radius*radius;
    }
    public void volume() {
        System.out.println("体积为： " + area()*height);
    }
    public static void main(String[] args){
        Cylinder c = new Cylinder(3.0, 2);
        c.setColor("红色");
        c.volume();
    }
    public String set(){return "1.0";}
}
