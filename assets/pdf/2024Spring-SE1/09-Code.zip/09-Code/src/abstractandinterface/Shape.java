package abstractandinterface;

abstract public class Shape {
    protected String name;
    public Shape(String xm){
        name = xm;
        System.out.println("名称 ：" + name);
    }
    abstract public double getArea();  //面积
    abstract public double getLength(); //周长

    public static  void main(String[] args){
//        Shape s = new Shape();
    }
}