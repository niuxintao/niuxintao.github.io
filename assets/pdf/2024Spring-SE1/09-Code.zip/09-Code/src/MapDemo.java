import java.util.Map;
import java.util.TreeMap;

class MapDemo {
    public static void main(String[] args){
        Map<String, String> L = new TreeMap<>();
        L.put("dog", "woof");
        L.put("cat", "meow");
        String sound = L.get("cat");
        System.out.println(sound);
        System.out.println(L);
    }
}