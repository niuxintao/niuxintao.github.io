class Drawing extends Art {
    Drawing() {
        System.out.println("Drawing Constructor");
    }
}