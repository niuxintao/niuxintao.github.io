class Main {

    String language;

//    structor with no parameter
//    Main() {
//        this(5, 2);
//        this.language = "Java";
//    }
//    // second constructor
//    Main(int arg1, int arg2) {
//        // add two value
//        System.out.println(arg1 + arg2);
//    }
//
//    // constructor with a single parameter
//    Main(String language) {
//        this.language = language;
//    }    // con

    /**
     *  function name : getName()
     */
    public void getName() {
        System.out.println("Programming Langauage: " + this.language);
    }

    public static void main(String[] args) {

        // call constructor with no parameter
        Main obj1 = new Main();

        // call constructor with a single parameter
        Main obj2 = new Main();

        obj2.language = "";
        obj1.getName();
        obj2.getName();
//        Main 进展 = new Main();
//        进展.getName();
    }
}