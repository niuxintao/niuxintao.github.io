package other;

import java.util.Scanner;
import java.io.File;
import java.io.PrintWriter;

class ReadAndWriter {
  public static void main(String[] args) { 
    try{
         String fileInput = "file.txt";
         String fileOutput = "out.txt";
         Scanner myObj = new Scanner(new File(fileInput));
         PrintWriter fileOut = new PrintWriter(new File(fileOutput));
         while(myObj.hasNextLine()){
              String line = myObj.nextLine();
              fileOut.println(line);
          }
          myObj.close();
          fileOut.close();
     }
     catch(Exception e){
        throw new RuntimeException(e);
     }
  }
}