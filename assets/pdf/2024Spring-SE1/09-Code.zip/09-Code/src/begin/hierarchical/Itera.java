package begin.hierarchical;

import begin.IterAndMutate;

public class Itera {
	begin.Itera i;
	IterAndMutate iam;
}
