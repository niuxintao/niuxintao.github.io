package begin;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class Itera {
	public static void main(String[] args) {
		List<String> cities  = new ArrayList<>();
		Set<Integer> numbers = new HashSet<>();
		Map<String,Integer> turtles = new HashMap<>();
		
		cities.add("nanjing");
		cities.add("shanghai");
		cities.add("beijing");
		
		numbers.add(1);
		numbers.add(2);
		numbers.add(3);
		
		turtles.put("1", 1);
		turtles.put("2", 2);
		turtles.put("3", 2);

		
		for (String city : cities) {
		    System.out.println(city);
		}
		for (int num : numbers) { 
		    System.out.println(num);
		}
	
		for (String key : turtles.keySet()) {
		    System.out.println(key + ": " + turtles.get(key));
		}
		
		Iterator<String> i_ci = cities.iterator(); 
		while( i_ci.hasNext()) {
			System.out.println(i_ci.next());
		}
		
		Iterator<Integer> i_nu = numbers.iterator(); 
		while( i_nu.hasNext()) {
			System.out.println(i_nu.next());
		}
		
		for (Entry<String, Integer> entry : turtles.entrySet()) {
		    System.out.println(entry.getKey() + ": " + entry.getValue());
		}
		
	
		
	}
}
