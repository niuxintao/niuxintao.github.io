package begin;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

public class IterAndMutate {
	
	public static void main(String[] args) {
//		List<Integer> numbers = new ArrayList<Integer>(Arrays.asList(100, 200, 300));
//		for (Integer num : numbers){
//		    numbers.remove(num); // danger!!! mutates the list we're iterating over
//		}
//		System.out.println(numbers); /* list should be empty here -- is it? */


//		List<Integer>List numbers = new ArrayList<Integer>(Arrays.asList(100, 200, 300));
//		List<Integer> newList = new ArrayList<Integer>();
//		for (Integer num : numbers){
//		    if (num > 100)
//		         newList.add(num);
//		}
//		System.out.println(newList); /* list should be empty here -- is it? */

//		
		List<Integer> numbers = new ArrayList<Integer>(Arrays.asList(100, 200, 300));
		Iterator<Integer> iter = numbers.iterator();
		while(iter.hasNext()){
			Integer num = iter.next();
			if (num <= 100)
				iter.remove();
		}

		System.out.println(numbers);
	}

}
