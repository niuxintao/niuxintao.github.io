
public class Dog extends Animal {
    public String name = "dog";
    public static void something() {
        // This method merely hides Animal.something(),
        // but does not override it
        System.out.println("dog.something");
    }
    public void eat() {
        // This method overrides eat(),
        // and will affect calls to eat()
        System.out.println("dog.eat");
    }
    public Dog() {
    }
    public static void main(String[] args) {
        Animal animal = new Dog();
        System.out.println(animal.name);
        animal.something();
        animal.eat();


//        Dog  somedog = (Dog) new Animal();
        Animal c = new Animal();
        System.out.println( c instanceof Dog);
        if(animal instanceof Dog) {
            Dog dog = (Dog) animal;
        }


    }
}