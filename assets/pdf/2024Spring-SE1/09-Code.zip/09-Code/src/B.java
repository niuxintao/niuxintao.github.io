
class A {
    private int m = 0;
    int i=256, j =64;
    static int k = 32;
    final float e = 2.718f;
}

public class B extends A {
    public char j='x';
    final double k =5;
    static int e =321;
    void show() { System.out.println(i + " " + j + " " +  k + " " + e );  }
    void showA() { System.out.println(super.j + " " + super.k + " " + super.e); }
    public static void main(String[] args) {
        B b = new B();
        b.show();
        b.showA();
    }
}