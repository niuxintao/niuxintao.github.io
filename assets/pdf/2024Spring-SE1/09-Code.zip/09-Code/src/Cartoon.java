public class Cartoon extends Drawing {
    Cartoon() {
//        super();
//        this(1);
        System.out.println("Cartoon Constructor");
    }

    Cartoon(int a){
        System.out.println("a");
    }

    public static void main(String args[]) {
        Cartoon c = new Cartoon();
    }
}