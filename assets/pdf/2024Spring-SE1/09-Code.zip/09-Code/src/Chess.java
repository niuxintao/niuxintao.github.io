class Game {
    protected Game get(){
        return null;
    }
    protected Game get(int i){
        return null;
    }
    protected Game get(int i, boolean b){
        return null;
    }
    protected Game get(boolean b, int i){
        return null;
    }

    public Game get(long a){
        return null;
    }
    Game(){

    }
    Game(int i) {
        System.out.println("Game Constructor");
    }
}
class BoardGame extends Game {
    public BoardGame get(){
        return null;
    }
    BoardGame(int i) {
//        super(i);
        System.out.println("BoardGame Constructor");
    }
}
public class Chess extends BoardGame {
    Chess() {
        super(3);
        System.out.println("Cartoon Constructor");
    }
    public static void main(String args[]) {
        Chess c = new Chess();
    }
}