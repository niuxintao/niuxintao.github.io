public class Animal {
    public String name = "animal";
    public static void something() {
        System.out.println("animal.something");
    }
    public void eat() {
        System.out.println("animal.eat");
    }
    public Animal() {
    }
}