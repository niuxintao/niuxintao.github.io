#sequence

chocolate_bars = ("90%", "70%", "55%")

worst_first = reversed(chocolate_bars)

for chocolate in worst_first:
    print(chocolate)


####zip

eng_nums = ["one", "two", "three"]
esp_nums = ["uno", "dos", "tres"]

zip_iter = zip(eng_nums, esp_nums)
eng, esp = next(zip_iter)
print(eng, esp)

for eng, esp in zip(eng_nums, esp_nums):
    print(eng, esp)


###map
nums = [1, 2, 3, 4, 5]

# Map returns an iterator
squares1 = map(lambda num: num ** 2, nums)

# Create a list of all the elements from the iterator
squares1 = list(squares1)

# Compare to...
squares2 = [num**2 for num in nums]


# multiple iterables

list(map(lambda x, y: x - y, [2, 4, 6], [1, 3, 5]))



####fliter
nums = [1, 2, 3, 4, 5]

# Filter returns an iterator
even1 = filter(lambda num: num % 2 == 0, nums)

# Create a list of all the elements from the iterator
even1 = list(even1)

# Compare to...
even2 = [num for num in nums if num % 2 == 0]



### list, tuple and sorted
nums = [2, 3, 1, 5, 4]
it_num = iter(nums)
next(it_num)
list(it_num)
next(it_num)


it_num = iter(nums)
tu_num = tuple(it_num)
tu_num

it_num = iter(nums)
so_num = sorted(it_num)
so_num


#generator

def foo(x):
    yield x

y = 7
g = foo(y)
y = 0
print(next(g))




import time

start = time.perf_counter()
def find_matches(filename, match):
    for line in open(filename):
        if line.find(match) > -1:
            yield line

line_iter = find_matches('frankenstein.txt', "!")
next(line_iter)
next(line_iter)
end = time.perf_counter()
print(end - start)



start = time.perf_counter()
def find_matches(filename, match):
    matched = []
    for line in open(filename):
        if line.find(match) > -1:
            matched.append(line)
    return matched

matched_lines = find_matches('frankenstein.txt', "!")
matched_lines[0]
matched_lines[1]

end = time.perf_counter()
print(end - start)