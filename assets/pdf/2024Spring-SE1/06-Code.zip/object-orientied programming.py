class Product:
    # Set the initial values
    def __init__(self, name, price, nutrition_info):
        self.name = name
        self.price = price
        self.nutrition_info = nutrition_info
        self.inventory = 0
    # Define methods
    def increase_inventory(self, amount):
        self.inventory += amount
    
    def reduce_inventory(self, amount):
        self.inventory -= amount
        
    def get_label(self):
        return "Foxolate Shop: " + self.name
        
    def get_inventory_report(self):
        if self.inventory == 0:
            return "There are no bars!"
        return f"There are {self.inventory} bars."
        
    def __eq__(self, other):
        return not self.name == other.name and self.price == other.price and self.nutrition_info == other.nutrition_info and self.inventory == other.inventory



a = Product("Piña Chocolotta", 7.99,
    ["200 calories", "24 g sugar"])
b = Product("Piña Chocolotta", 7.99,
    ["200 calories", "24 g sugar"])



class Product:
    sales_tax = 0.07
    # Set the initial values
    def __init__(self, name, price, nutrition_info):
        self.name = name
        self.price = price
        self.nutrition_info = nutrition_info
        self.inventory = 0
    # Define methods
    def increase_inventory(self, amount):
        self.inventory += amount
    
    def reduce_inventory(self, amount):
        self.inventory -= amount
        
    def get_label(self):
        return "Foxolate Shop: " + self.name
    
    def get_total_price(self, quantity):
        return (self.price * (1 + self.sales_tax)) * quantity
        
    def get_inventory_report(self):
        if self.inventory == 0:
            return "There are no bars!"
        return f"There are {self.inventory} bars."