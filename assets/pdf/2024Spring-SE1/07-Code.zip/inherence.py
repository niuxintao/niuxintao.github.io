class Food:
    def __init__(self, name, type, calories):
        self.name = name
        self.type = type
        self.calories = calories

class Animal:
    species_name = "Animal"
    scientific_name = "Animalia"
    calories_needed = 100
    play_multiplier = 2
    interact_increment = 1
    def __init__(self, name, age=0):
        self.name = name
        self.age = age
        self.calories_eaten  = 0
        self.happiness = 0
    def play(self, num_hours):
        self.happiness += (num_hours * self.play_multiplier)
        print("WHEEE PLAY TIME!")
    def eat(self, food):
        self.calories_eaten += food.calories
        print(f"Om nom nom yummy {food.name}")
        if self.calories_eaten > self.calories_needed:
            self.happiness -= 1
            print("Ugh so full")
    def interact_with(self, animal2):
        self.happiness += self.interact_increment
        print(f"Yay happy fun time with {animal2.name}")


### override class varaibles

class Rabbit(Animal):
    species_name = "European rabbit"
    scientific_name = "Oryctolagus cuniculus"
    calories_needed = 200
    play_multiplier = 8
    interact_increment = 4
    num_in_litter = 12

class Elephant(Animal):
    species_name = "African Savanna Elephant"
    scientific_name = "Loxodonta africana"
    calories_needed = 8000
    play_multiplier = 4
    interact_increment = 2
    num_tusks = 2


### override methods
class Panda(Animal):
    species_name = "Giant Panda"
    scientific_name = "Ailuropoda melanoleuca"
    calories_needed = 6000
    def interact_with(self, other):
        print(f"I'm a Panda, I'm solitary, go away {other.name}!")
    def push_down_tree(self):
        print("I will push down the tree!")

panda1 = Panda("Pandeybear", 6)
panda2 = Panda("Spot", 3)
panda1.interact_with(panda2)



### use super()

class Lion(Animal):
    species_name = "Lion"
    scientific_name = "Panthera"
    calories_needed = 3000
    
    def eat(self, food):
        if food.type == "meat":
            super().eat(food)

bones = Food("Bones", "meat", 100)
mufasa = Lion("Mufasa", 10)
mufasa.eat(bones)



### override __init__

class Elephant(Animal):
    species_name = "Elephant"
    scientific_name = "Loxodonta"
    calories_needed = 8000
    
    def __init__(self, name, age=0):
        super().__init__(name, age)
        if age < 1:
            self.calories_needed = 1000
        elif age < 5:
            self.calories_needed = 3000

elly = Elephant("Ellie", 3)
elly.calories_needed

class Elephant(Animal):
    species_name = "Elephant"
    scientific_name = "Loxodonta"
    calories_needed = 8000

elly = Elephant("Ellie", 3)
elly.calories_etan


class Elephant(Animal):
    species_name = "Elephant"
    scientific_name = "Loxodonta"
    calories_needed = 8000
    
    def __init__(self, name, age=0):
        if self.age < 1:
            self.calories_needed = 1000
        elif age < 5:
            self.calories_needed = 3000

elly = Elephant("Ellie", 3)
elly.calories_needed



### layers of inheritance

class Herbivore(Animal):
     def eat(self, food):
        if food.type == "meat":
            self.happiness -= 5
        else:
            super().eat(food)

class Carnivore(Animal):
    def eat(self, food):
        if food.type == "meat":
            super().eat(food)


class Rabbit(Herbivore):
    species_name = "European rabbit"
    scientific_name = "Oryctolagus cuniculus"
    calories_needed = 200
    play_multiplier = 8
    interact_increment = 4
    num_in_litter = 12

class Panda(Herbivore):
    species_name = "Giant Panda"
    scientific_name = "Ailuropoda melanoleuca"
    calories_needed = 6000
    def interact_with(self, other):
        print(f"I'm a Panda, I'm solitary, go away {other.name}!")
    def push_down_tree(self):
        print("I will push down the tree!")


class Elephant(Herbivore):
    species_name = "Elephant"
    scientific_name = "Loxodonta"
    calories_needed = 8000
    
    def __init__(self, name, age=0):
        if self.age < 1:
            self.calories_needed = 1000
        elif age < 5:
            self.calories_needed = 3000

class Hawk(Carnivore):
    species_name = "Red-tailed hawk"
    scientific_name = "Oryctolagus cuniculus"
    calories_needed = 1000

class Lion(Carnivore):
    species_name = "Lion"
    scientific_name = "Accipitridae"
    calories_needed = 3000
    
    def eat(self, food):
        if food.type == "meat":
            super().eat(food)


### multiple inheritance

class Predator(Animal):
    def encounter(self, other):
        if other.type == "meat":
            self.eat(other)
            print("om nom nom, I'm a predator")
        else:
            super().interact_with(other)

class Prey(Animal):
    type = "meat"
    calories = 200

class Rabbit(Prey, Herbivore):
    species_name = "European rabbit"
    scientific_name = "Oryctolagus cuniculus"
    calories_needed = 200
    play_multiplier = 8
    interact_increment = 4
    num_in_litter = 12

class Lion(Predator, Carnivore):
    species_name = "Lion"
    scientific_name = "Panthera"
    calories_needed = 3000
    
    def eat(self, food):
        if food.type == "meat":
            super().eat(food)


r = Rabbit("Peter", 4)   
r.play(5)
r.type   
r.eat(Food("carrot", "veggies", 100)) 
l = Lion("Scar", 12)  
l.eat(Food("zazu", "meat", 1000)) 
l.encounter(r) 


### MRO

class A:
  def save(self): pass

class B(A): pass

class C:
  def save(self): pass

class D(B, C): pass



### composition

class Animal:
    def mate_with(self, other):
        if other is not self and other.species_name == self.species_name:
            self.mate = other
            other.mate = self

mr_wabbit = Rabbit("Mister Wabbit", 3)
jane_doe = Rabbit("Jane Doe", 2)
mr_wabbit.mate_with(jane_doe)



class Rabbit(Animal):
   
    def reproduce_like_rabbits(self):
        if self.mate is None:
            print("oh no! better date  someone")
            return
        self.babies = []
        for _ in range(0, self.num_in_litter):
            self.babies.append(Rabbit("bunny", 0))

mr_wabbit = Rabbit("Mister Wabbit", 3)
jane_doe = Rabbit("Jane Doe", 2)
mr_wabbit.mate_with(jane_doe)
jane_doe.reproduce_like_rabbits()


class Conservatory:
    def __init__(self, animals):
        self.animals = animals
    def partytime(self):
        """Assuming ANIMALS is a list of Animals, cause each
        to interact with all the others exactly once."""
        for i in range(len(self.animals)):
            for j in range(i + 1, len(animals)):
                animals[i].interact_with(animals[j])

jane_doe = Rabbit("Jane Doe", 2)
l = Lion("Scar", 12)
panda1 = Panda("Pandeybear", 6)
el1 = Elephant("Willaby", 5)
con = Conservatory([jane_doe, l, panda1, el1])


### mixin
class MappingMixin:
    def __getitem__(self, key):
        return self.__dict__.get(key)
    
    def __setitem__(self, key, value):
        return self.__dict__.set(key, value)


class Animal:
    species_name = "Animal"
    scientific_name = "Animalia"
    calories_needed = 100
    play_multiplier = 2
    interact_increment = 1
    def __init__(self, name, age=0):
        self.name = name
        self.age = age
        self.calories_eaten  = 0
        self.happiness = 0
    def play(self, num_hours):
        self.happiness += (num_hours * self.play_multiplier)
        print("WHEEE PLAY TIME!")
    def eat(self, food):
        self.calories_eaten += food.calories
        print(f"Om nom nom yummy {food.name}")
        if self.calories_eaten > self.calories_needed:
            self.happiness -= 1
            print("Ugh so full")
    def interact_with(self, animal2):
        self.happiness += self.interact_increment
        print(f"Yay happy fun time with {animal2.name}")


class Rabbit(MappingMixin, Animal):
    pass

r = Rabbit("Peter", 4)   
r['name']
