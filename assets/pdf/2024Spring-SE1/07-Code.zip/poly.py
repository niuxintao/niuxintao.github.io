class Dog:
	
	def __init__(self):
		self.__repr__ = lambda: 'teddy'
		self.__str__ = lambda: 'a teddy'

	def __repr__(self):
		return 'Dog()'
	def __str__(self):
		return 'a dog'

def repr(x):
	return type(x).__repr__(x)

def str(x):
	t = type(x)
	if hasattr(t, '__str__'):
		return t.__str__(x)
	else:
		return repr(x)

teddy = Dog()
print(teddy)
print(repr(teddy))
print(str(teddy))
print(teddy.__repr__())
print(teddy.__str__())


class Comb:
    def __init__(self, a, b):
        self.a = a
        self.b = b
    
    def __add__(self, other):
        return Comb(self.a+other.a, self.b+other.b)
    
    def __repr__(self):
        return '{0}, {1}'.format(self.a, self.b)

c1 = Comb(1, 2)
c2 = Comb(2, 3)
c1+c2


class Ratio:
	def __init__(self, n, d):
		self.numer = n
		self.denom = d
	
	def __repr__(self):
		return 'Ratio({0},{1})'.format(self.numer, self.denom)
	
	def __str__(self):
		return '{0}/{1}'.format(self.numer, self.denom)
		
	def __add__(self, other):
		if isinstance(other, int):
			n = self.numer + self.denom * other
			d = self.denom
		if isinstance(other, float):
			return float(self) + other
		elif isinstance(other, Ratio):
			n = self.numer * other.denom + self.denom * other.numer
			d = self.denom * other.denom
		g = gcd(n, d)
		return Ratio(n//g, d//g)
	
	def __float__(self):
		return self.numer/self.denom

def gcd(n, d):
	while n != d:
		n, d = min(n,d), abs(n-d)
	return n



class Lamb:
	species_name = "Lamb"
	scientific_name = "Ovis aries"
	
	def __init__(self, name):
		self.name = name
	
	def __str__(self):
		return "Lamb named " + self.name
	
	def __repr__(self):
		return f"({repr(self.name)})"