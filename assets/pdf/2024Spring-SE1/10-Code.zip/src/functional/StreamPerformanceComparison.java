package functional;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.stream.Collectors;

public class StreamPerformanceComparison {

    public static void main(String[] args) {
        int dataSize = 1000;
        List<Integer> randomNumbers = generateRandomNumbers(dataSize);

        // Measure time for sequential stream
        long startTime = System.currentTimeMillis();
        randomNumbers.stream().sorted().collect(Collectors.toList());
        long endTime = System.currentTimeMillis();
        long sequentialTime = endTime - startTime;
        System.out.println("Sequential stream time: " + sequentialTime + " ms");

        // Measure time for parallel stream
        startTime = System.currentTimeMillis();
        randomNumbers.parallelStream().sorted().collect(Collectors.toList());
        endTime = System.currentTimeMillis();
        long parallelTime = endTime - startTime;
        System.out.println("Parallel stream time: " + parallelTime + " ms");
    }

    private static List<Integer> generateRandomNumbers(int size) {
        Random random = new Random();
        List<Integer> randomNumbers = new ArrayList<>(size);
        for (int i = 0; i < size; i++) {
            randomNumbers.add(random.nextInt(100));
        }
        return randomNumbers;
    }
}
