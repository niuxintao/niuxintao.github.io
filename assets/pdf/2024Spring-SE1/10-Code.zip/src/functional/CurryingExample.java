package functional;

import java.util.function.Function;

public class CurryingExample {
    // 定义一个接受三个参数的函数
    public static int add(int a, int b, int c) {
        return a + b + c;
    }

    // 柯里化函数，将一个三参数函数分解为一系列单参数函数
    public static Function<Integer, Function<Integer, Function<Integer, Integer>>> curriedAdd() {
        return a -> b -> c -> add(a, b, c);
    }

    public static void main(String[] args) {
        // 使用柯里化函数
        Function<Integer, Function<Integer, Function<Integer, Integer>>> curried = a -> b -> c -> (a + b + c);

        Function<Integer, Function<Integer, Integer>> sample = curried.apply(1);
        Function<Integer, Integer> sa2 =  sample.apply(2);
        sa2.apply(5);
        // 调用柯里化函数
        int result = curried.apply(1).apply(2).apply(3);
        System.out.println("Result: " + result); // 输出结果：Result: 6
    }
}
