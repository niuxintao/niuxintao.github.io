package functional;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.function.Consumer;
//import java.util.function.Function;


interface xx {
    int display(int number);
}

public class LambdaDemo {

    public static void main(String[] args){
        ArrayList<Integer> numbers = new ArrayList<Integer>();
        numbers.add(5);
        numbers.add(9);
        numbers.add(8);
        numbers.add(1);
        numbers.forEach( (n) -> { System.out.print(n + "\t"); } );

        System.out.println();



        List<Integer> primes = Arrays.asList(new Integer[]{2, 3,5,7});
        Integer factor = 2;
//        primes.forEach(element -> { factor++; });
//        primes.forEach(element -> { primes.set(primes.indexOf(element), element + 1); });

//        primes.forEach(element -> { element++; });
        primes.forEach( (n) -> { System.out.print(n + "\t" ); } );
        System.out.println();



        Consumer<Integer> a =  (n) -> { System.out.print(n + "\t");};
        numbers.forEach(a);

        /*
        store lambda in a variable of type interface that has
        only one method.
         */
        xx lambda = (n) -> {
            return 0;
        };

        System.out.println(lambda.display(20));
    }
}
