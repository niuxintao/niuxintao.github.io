package functional;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class StreamDemo {
    public static void main(String[] args){
        List<String> strings2 = Arrays.asList("abc", "", "bc", "efg", "abcd","", "jkl");
        List<String> filtered2 = strings2.stream().filter(string -> !string.isEmpty()).collect(Collectors.toList());
        System.out.println(strings2);
        System.out.println(filtered2);


        List<Integer> numbers = Arrays.asList(3, 2, 2, 3, 7, 3, 5);
        List<Integer> squaresList = numbers.stream().map( i -> i*i).collect(Collectors.toList());
        System.out.println("squaresList:  " + squaresList);
        squaresList = numbers.stream().map( i -> i*i).distinct().collect(Collectors.toList());
        System.out.println("distinct squaresList:  " + squaresList);


        List<String>strings = Arrays.asList("abc", "", "bc", "efg", "abcd","", "jkl");
        long count = strings.stream().filter(string -> string.isEmpty()).count();
        System.out.println("empty string count:  " + count);

        numbers = Arrays.asList(3, 2, 2, 3, 7, 3, 5);
        List<Integer> sortedList = numbers.stream().sorted().collect(Collectors.toList());
        System.out.println("sortedList:  " + sortedList);
        sortedList = numbers.stream().sorted(Comparator.reverseOrder()).collect(Collectors.toList());
        System.out.println("reverse sortedList:  " + sortedList);
        numbers.stream().sorted((a, b) -> -(a.compareTo(b))).forEach(n ->  System.out.print(n + " \t") );
        System.out.println();

        int reduced = IntStream.range(1, 5).reduce((a, b) -> a + b).getAsInt();
        System.out.println("range of [1, 5) reduce to :" + reduced);


        Stream<Integer> stream = Stream.iterate(0, (x) -> x + 2).limit(6);
        stream.forEach(System.out::println);

        List<Integer> list = Arrays.asList(1, 2, 3, 4, 5);
        boolean allMatch = list.stream().allMatch(e -> e > 3); //false
        boolean anyMatch = list.stream().anyMatch(e -> e > 3);  //true
        boolean noneMatch = list.stream().noneMatch(e -> e > 10); //true

        System.out.println("allMatch: " + allMatch + "\nanyMatch: "  + anyMatch + "\nnoneMatch: "+ noneMatch);

        list = Arrays.asList(1, 2, 3, 4, 5);
        Integer max = list.stream().max((a, b) -> a.compareTo(b)).get(); //5
        Integer min = list.stream().min(Integer::compareTo).get(); //1
        System.out.println("max: "+ max + "  min:" + min );


    }
}
