package functional;

import java.util.Arrays;
import java.util.List;

public class ParalDemo {

    public static void main(String[] args){
        List<Integer> list = Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 9, 10);
        // 使用并行流计算平方和

        //Stream<Integer> sequentialStream = list.stream();
        //Stream<Integer> parallelStream = sequentialStream.parallel();
        int sumOfSquares = list.parallelStream().mapToInt(i -> i * i).sum();
        System.out.println("Sum of squares: " + sumOfSquares);
    }
}
