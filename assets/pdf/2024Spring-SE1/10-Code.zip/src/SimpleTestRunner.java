import java.lang.reflect.Method;

public class SimpleTestRunner {

    public static void main(String[] args) throws Exception {
        Class<?> testClass = Class.forName("Main");
        Object testInstance = testClass.getDeclaredConstructor().newInstance();

        Method[] methods = testClass.getDeclaredMethods();
        Method beforeEachMethod = null;

        // 找到 @BeforeEach 方法
        for (Method method : methods) {
            if (method.isAnnotationPresent(BeforeEach.class)) {
                beforeEachMethod = method;
                break;
            }
        }

        // 运行标记了 @Test 的方法
        for (Method method : methods) {
            if (method.isAnnotationPresent(Test.class)) {
                if (beforeEachMethod != null) {
                    beforeEachMethod.invoke(testInstance);
                }
                method.invoke(testInstance);
            }
        }
    }
}
