package reflection;

import java.lang.reflect.*;
public class TestInvoke {
    public int add(int a, int b) {
        return a + b;
    }
    public static void main(String args[])
    {
        try {
            Class cls = Class.forName("reflection.TestInvoke");
            Class partypes[] = new Class[2];
            partypes[0] = Integer.TYPE;
            partypes[1] = Integer.TYPE;

            Method meth = cls.getMethod("add", partypes);
            TestInvoke methobj = new TestInvoke();
            Object arglist[] = new Object[2];
            arglist[0] =  Integer.valueOf(37);
            arglist[1] = Integer.valueOf(47);
            Object retobj  = meth.invoke(methobj, arglist);
            Integer retval = (Integer)retobj;

//            methobj.add(37, 47);

            System.out.println(retval.intValue());
        }
        catch (Throwable e) {
            System.err.println(e);
        }
    }
}