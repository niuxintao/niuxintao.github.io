package reflection;

import java.lang.reflect.*;

public class TestConstruct {
    public TestConstruct(){
    }
    public TestConstruct(int a, int b){
        System.out.println(
                "a = " + a + " b = " + b);
    }
    public static void main(String args[])
    {
        try {
            Class cls = Class.forName("reflection.TestConstruct");
            Class partypes[] = new Class[2];
            partypes[0] = Integer.TYPE;
            partypes[1] = Integer.TYPE;
            Constructor ct = cls.getConstructor(partypes);
            Object arglist[] = new Object[2];
            arglist[0] =  Integer.valueOf(37);
            arglist[1] =  Integer.valueOf(47);
            Object retobj = ct.newInstance(arglist);

//            TestConstruct obj = new TestConstruct(37, 47);

        }
        catch (Throwable e) {
            System.err.println(e);
        }
    }
}