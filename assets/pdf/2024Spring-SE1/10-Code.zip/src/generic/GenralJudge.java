package generic;

public class GenralJudge<T> {
    public void createObj(){
//        T b = new T();
    }
    public T get(T a){
        return a;
    }

    public static void main(String[] args){
        GenralJudge<String> a = new GenralJudge<>();

        GenralJudge c = new GenralJudge();

        String str = a.get("SS");
        String str2 = (String) c.get("String");
//        System.out.println(c.get(1));

        System.out.println(a instanceof GenralJudge<String>);

        System.out.println(c instanceof GenralJudge<?>);
    }
}
