package generic;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class GenericsSample<T, E extends Number, F> {
    private T  obj;
    protected E  something;
    protected F  otherthing;
    public T getObj(){
//        T a = new T();
        return obj;
    }
    public void set(E something, F otherthing){
        this.something = something;
        this.otherthing = otherthing;
    }
    public void setObj(T obj){
        this.obj = obj;
    }
    public static void main(String[] args){
        GenericsSample<String, Integer, Double> t1 = new GenericsSample<>();
//        System.out.println(t1 instanceof  GenericsSample<?, ?, String>);
        GenericsSample<Integer, Long, List> t2 = new GenericsSample<Integer, Long, List>();
        t1.setObj("Tom");
        t2.set(12L, new ArrayList<Integer>(Arrays.asList(100, 200, 300) ) );
    }
}