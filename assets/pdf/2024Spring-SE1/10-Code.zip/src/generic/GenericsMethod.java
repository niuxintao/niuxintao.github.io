package generic;

public class GenericsMethod {
    public static <E> void display(E[] list){
        for(E e : list){
            System.out.print(e + " ");
        }
        System.out.println();
    }
    public <E, V> void display(E[] list, V[] list2){
        for(E e : list){
            System.out.print(e + " ");
        }
        System.out.println();

        for(V e : list2){
            System.out.print(e + " ");
        }
        System.out.println();
    }
    public static void main(String[] args){
        Integer[] num = {1, 2 ,3, 4, 5};
        String[] strs = {"赤", "橙","黄", "绿", "青", "蓝","紫"};
        GenericsMethod.display(num);
        GenericsMethod.display(strs);
        GenericsMethod app = new GenericsMethod();
        app.display(num, strs);
    }
}