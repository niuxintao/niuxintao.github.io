package generic;

public interface GenericsInterface<E> {
    E getAge();
    void printAge(E e);
}