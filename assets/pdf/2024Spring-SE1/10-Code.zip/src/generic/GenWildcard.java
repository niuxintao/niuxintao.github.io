package generic;

public class GenWildcard <T> {
    T obj;
    public void setObj (T obj){
        this.obj = obj;
    }
    public T getObj(){
        return obj;
    }
    public static void main(String[] args) {
        GenWildcard <? extends Number> x = null;
        x = new GenWildcard <Long> ();
        x = new GenWildcard <Integer> ();
        Number a = x.getObj(); //Correct
//        x.setObj(Integer.valueOf(1)); //Error

        GenWildcard <? super Number> y = null;
        y = new GenWildcard<Object>();
        y = new GenWildcard<Number>();
//        Number b = y.getObj();
        y.setObj(Integer.valueOf(1));
    }
}
