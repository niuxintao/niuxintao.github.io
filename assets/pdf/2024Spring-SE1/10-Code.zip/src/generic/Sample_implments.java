package generic;

public class Sample_implments implements GenericsInterface<Integer> {
    public Integer getAge() {
        return 0;
    }
    public void printAge(Integer o) {
        System.out.println("年龄："+o);
    }

    public static void main(String[] args) {
        Sample_implments obj = new Sample_implments();
        obj.printAge(10);
        obj.printAge(20);
    }
}