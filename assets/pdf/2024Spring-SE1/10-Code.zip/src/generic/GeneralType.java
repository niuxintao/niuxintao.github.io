package generic;

class GeneralType <T extends Number> {
    T obj;

    public GeneralType (T obj){
        this.obj = obj;
    }
    public T getObj(){
        return obj;
    }
    public void setObj(T obj){
        this.obj = obj;
    }

    public String toString(){
        return "allthesame";
    }
    public static void main(String[] args) {
        GeneralType<? super Integer> num = new GeneralType<Integer>(5);
//        Number a = num.getObj();
        num.setObj(5);
        System.out.println(num);

//        GeneralType<String> num = new GeneralType<String>("5");
//        System.out.println("给出的参数是： "+ num.getObj());
    }
}