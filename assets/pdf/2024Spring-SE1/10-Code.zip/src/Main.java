public class Main {
    @BeforeEach
    public void setup() {
        System.out.println("Setup before each test");
    }

    @Test
    public void test1() {
        System.out.println("Running test1");
    }

    @Test
    public void test2() {
        System.out.println("Running test2");
    }

    public void notATest() {
        System.out.println("This is not a test method");
    }
}
