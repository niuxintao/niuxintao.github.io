def main():
    sys_write('Hello, OS World\n')  # sys_write -> print
